import React from 'react';
import Image from './Assets/images/LOGO.jpg';
import Image1 from './Assets/icons/Home.png';
import Image2 from './Assets/icons/Product.png';
import Image3 from './Assets/icons/AboutUs.png';
import Image4 from './Assets/icons/ContactUs.png';
import { BrowserRouter as Router, Route, NavLink, Switch, Routes, BrowserRouter } from "react-router-dom";
import { HashLink as Link } from 'react-router-hash-link';
import './Header.css';

export default function Header(props) {
    return (
        <header className='row-block-center'>
            <div  className='row-header'>
            <div className='row1'>
            <div  >
                <Link to ="/Home">
                <a >Logo</a>
                <img src={Image} height="50px" width="50px" alt="Logo" />
                </Link>
            </div>
            </div>
            <div className='row2'>
            <div>
               <Link to='/Home'>
               <a >Home</a>
                <img src={Image1} height="50px" width="50px" alt="Home" />
               </Link>
            </div>
            <div>
                <Link to='/Products' >
                    <a>Products</a>
                    <img src={Image2} height="50px" width="50px" alt="Products" /></Link>
            </div>
            <div>
                <Link to='/Aboubtus'>
                    <a>Aboubtus</a>
                    <img src={Image3} height="50px" width="50px" alt="AboubtUs" /></Link>
            </div>
            <div>
                <Link to='/Contactus'>
                <a>Contactus</a>
                <img src={Image4} height="50px" width="50px" alt="ContactUs" /></Link>
            </div>
            </div>
            </div>
        </header>
    );
}