import axios from 'axios';
import React, { Component, useEffect, useState } from 'react';
import Feedbackform from './Feedbackform';
import Emoji from './Emoji';
import StarRating from './starrating';
{/* <script>
	handlesubmit(e){
		<form >
		<label>
		  Name:
		  <input type="text"  value="text"/>
		  Email:
		  <input type="text" value="text"/>
		</label>
		<label>
		Feedback:
		<textarea  />
		</label>
		<input type="submit"  value="text"  placeholder="minimum with 50wordsss" />
	  </form>
	}
</script> */}
const Products = () =>{
	const[products,setProducts]=useState([]);
	const[feedback,setFeedback]=useState(false);
	const[rating,setRating]=useState(false);
	const[emoji,setEmoji]=useState(false);
	useEffect(() =>{
	 const getProducts = async () =>{
	  const res =await axios.get('http://localhost:3000/product')
	  setProducts(res.data);
	//   console.log(res);

	}
	getProducts()
},[])
return(
	<div>
		<h2>Products are..</h2>
		<div style={{display:'flex'}}>
  {
		products.map((item, index) => (
          <div>
            <img src={item.url} />
            <p>{item.name}</p>
            <p>{item.brand}</p>
            <p>{item.price}</p>
			<button onClick={()=>setFeedback(!feedback)}>Feedback</button>
			<button onClick={()=>setRating(!rating)}  >Rating</button>
          </div>
    )
        )
      }
	  {
		feedback && (
			<Feedbackform feedback={feedback} setFeedback={setFeedback}/>
		)
	  }
	  {
		rating && (
			<StarRating  rating={rating} setRating={setRating}/>

		)
	  }
</div>
</div>
)
}

export default Products;