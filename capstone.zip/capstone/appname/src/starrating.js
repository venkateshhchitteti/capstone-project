import React, { useState } from "react";
import './starrating.css';
// const StarRating = () => {  
//   return (<p>Hello World</p>);
// };
// const StarRating = () => {
//     return (
//       <div className="star-rating">
//         {[...Array(5)].map((star) => {        
//           return (         
//             <span className="star">&#9733;</span>        
//           );
//         })}
//       </div>
//     );
//   };
const StarRating = () => {
    const [rating, setRating] = useState(0);
    const [hover, setHover] = useState(0);
  
    return (
      <form>
        <h1>Rating</h1>
        <div className="star-rating">
        {[...Array(5)].map((star, index) => {
          index += 1;
          return (
            <button
              type="button"
              key={index}
              className={index <= (hover || rating) ? "on" : "off"}
              onClick={() => setRating(index)}
              onDoubleClick={() => {
                setRating(0);
                setHover(0);
                }}
              onMouseEnter={() => setHover(index)}
              onMouseLeave={() => setHover(rating)}
            >
              <span className="star">&#9733;</span>
            </button>
          );
        })}
      </div>
      </form>
    );
  };
export default StarRating;